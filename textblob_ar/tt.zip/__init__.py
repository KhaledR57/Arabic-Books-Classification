from __future__ import absolute_import
from textblob_ar.blob import TextBlob
from textblob_ar.similarity import TextSimilarity
from textblob_ar.correction import TextCorrection

__version__ = '0.0.2'
__author__ = 'Adham Ehab'
__license__ = "MIT"
